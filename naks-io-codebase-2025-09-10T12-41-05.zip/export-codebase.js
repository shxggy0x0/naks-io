const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Create a zip file of the entire codebase
function exportCodebase() {
    try {
        console.log('Starting codebase export...');
        
        // Get the current directory (project root)
        const projectRoot = process.cwd();
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        const zipFileName = `naks-io-codebase-${timestamp}.zip`;
        
        // Create the zip file using PowerShell (since we're on Windows)
        const zipCommand = `powershell -Command "Compress-Archive -Path '${projectRoot}\\*' -DestinationPath '${projectRoot}\\${zipFileName}' -Force"`;
        
        console.log('Creating zip file...');
        execSync(zipCommand, { stdio: 'inherit' });
        
        console.log(`✅ Codebase exported successfully to: ${zipFileName}`);
        console.log(`📁 Location: ${path.join(projectRoot, zipFileName)}`);
        
        // Get file size
        const stats = fs.statSync(path.join(projectRoot, zipFileName));
        const fileSizeInMB = (stats.size / (1024 * 1024)).toFixed(2);
        console.log(`📊 File size: ${fileSizeInMB} MB`);
        
    } catch (error) {
        console.error('❌ Error exporting codebase:', error.message);
        process.exit(1);
    }
}

// Run the export
exportCodebase();
