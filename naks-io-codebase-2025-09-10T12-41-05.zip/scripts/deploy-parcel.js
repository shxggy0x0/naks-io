const hre = require("hardhat");

async function main() {
  console.log("🚀 Deploying ParcelNFT contract to local network...");
  
  // Get the deployer account
  const [deployer] = await hre.ethers.getSigners();
  console.log("📋 Deploying with account:", deployer.address);
  
  // Check balance
  const balance = await deployer.getBalance();
  console.log("💰 Account balance:", hre.ethers.utils.formatEther(balance), "ETH");

  // Deploy ParcelNFT contract
  console.log("📄 Deploying ParcelNFT...");
  const ParcelNFT = await hre.ethers.getContractFactory("ParcelNFT");
  const parcelNFT = await ParcelNFT.deploy();
  
  await parcelNFT.deployed();
  
  console.log("✅ ParcelNFT deployed successfully!");
  console.log("📍 Contract address:", parcelNFT.address);
  console.log("🔗 Transaction hash:", parcelNFT.deployTransaction.hash);
  
  // Set the deployer as an approved address (for minting)
  console.log("🔐 Setting deployer as approved address...");
  const approveTx = await parcelNFT.setApprovedAddress(deployer.address, true);
  await approveTx.wait();
  console.log("✅ Deployer approved for minting");
  
  console.log("\n📋 Deployment Summary:");
  console.log("======================");
  console.log("Contract Name: ParcelNFT");
  console.log("Network: localhost");
  console.log("Contract Address:", parcelNFT.address);
  console.log("Deployer:", deployer.address);
  console.log("Gas Used:", parcelNFT.deployTransaction.gasLimit.toString());
  
  console.log("\n🔧 Next Steps:");
  console.log("===============");
  console.log("1. Copy the contract address above");
  console.log("2. Set PARCEL_NFT_CONTRACT_ADDRESS in your .env.local:");
  console.log(`   PARCEL_NFT_CONTRACT_ADDRESS=${parcelNFT.address}`);
  console.log("3. Run the mint script:");
  console.log("   npx hardhat run --network localhost scripts/mint.js");
  
  return parcelNFT.address;
}

main()
  .then((address) => {
    console.log(`\n🎉 Deployment complete! Contract address: ${address}`);
    process.exit(0);
  })
  .catch((error) => {
    console.error("💥 Deployment failed:", error);
    process.exit(1);
  });

